print("Prime numbers",end='\n')

for n in range(2,1000):

    for i in range(2,n):

        if(n % i == 0):

            break

    else:
        # Loop fell through without finding a factor
        print(n,end='\n')  