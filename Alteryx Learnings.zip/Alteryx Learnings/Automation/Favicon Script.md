$source = "http://cnn.com/favicon.ico"

$destination = "C:\Users\nickj\OneDrive\Desktop\Assets\favicon.ico"

Invoke-WebRequest $source -OutFile $destination



Path = C:\Users\nickj\OneDrive\Desktop\Assets\curious.ps1



Powershell Command Arguments:



&".\curious.ps1"